<div class="container ">
    <div class="row g-5">
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-12 col-md-6 col-lg-4">
                <div class="card " style="width: 21rem; height: 580px;">
                    <img src="<?php echo e(asset($item->imageHeader()->fullAsset())); ?>" class="cd card-img-top" height="200px"
                        alt="...">
                    <div class="card-body">
                        <p class="fecha"><?php echo e($item->date); ?></p>
                        <h5 class="card-title"> <a href="" class="vinculoTitulo"><?php echo e($item->title); ?></a></h5>
                        <p class="card-text"><?php echo e($item->description); ?></p>
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('events.show', $item->id)); ?>" class="botonGC btn btn-danger">Leer
                            más...</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
    </div>


</div>
<?php /**PATH /var/www/html/resources/views/pages/events/table.blade.php ENDPATH**/ ?>