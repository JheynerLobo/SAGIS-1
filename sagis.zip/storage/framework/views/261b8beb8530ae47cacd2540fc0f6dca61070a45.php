<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-dark navbar-danger">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item color">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>

    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">



        <li class="nav-item">
            <a class="nav-link" data-widget="fullscreen" href="#" role="button">
                <i class="fas fa-expand-arrows-alt"></i>
            </a>
        </li>

        <li class="nav-item">

            <a class="nav-link" data-slide="true" role="button"
                href=""onclick="event.preventDefault(); $('#logout').submit();">
                <i class="fa fa-power-off"></i>

                <form action="<?php echo e(route('admin.logout')); ?>" method="post" id="logout">
                    <?php echo csrf_field(); ?>
                </form>

            </a>

        </li>
        

    </ul>
</nav>
<!-- ./Navbar -->
<?php /**PATH /var/www/html/resources/views/admin/partials/navbar.blade.php ENDPATH**/ ?>