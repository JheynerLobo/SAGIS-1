<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content-header'); ?>
    <?php echo $__env->make('admin.partials.content-header', [
        'title' => 'Dashboard',
        'items' => [],
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
           <h4>Funcionalidad Prevista para Software, Dashboard con diferentes tarjetas de información..</h4>
        </div>
        <!-- /.container-fluid -->
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/pages/home.blade.php ENDPATH**/ ?>