<?php if($editMode): ?>
    <!-- Form -->
    <form action="<?php echo e(route('admin.graduates.update', $item->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <!-- Name -->
        <div class="form-group">
            <label class="form-label">Nombres:</label>
            <input type="text" class="form-control " name="name" value="<?php echo e($item->name); ?>">
        </div>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./Name -->

        <!-- Lastname -->
        <div class="form-group">
            <label class="form-label">Apellidos:</label>
            <input type="text" class="form-control " name="lastname" value="<?php echo e($item->lastname); ?>">
        </div>
        <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./Lastname -->

        <!-- DocumentType -->
        <div class="form-group">
            <label>Tipo de Documento:</label>
            <select name="document_type_id" class="form-control select2bs4">
                <option value="-1">Seleccione un tipo de documento..</option>
                <?php $__empty_1 = true; $__currentLoopData = $documentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documentType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($documentType->id); ?>"
                        <?php echo e(isSelectedOld($item->document_type_id, $documentType->id)); ?>><?php echo e($documentType->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </select>
        </div>
        <?php $__errorArgs = ['document_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./DocumentType -->

        <!-- Document -->
        <div class="form-group">
            <label class="form-label">Documento:</label>
            <input type="number" class="form-control " name="document" value="<?php echo e($item->document); ?>">
        </div>
        <?php $__errorArgs = ['document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./Document -->

        <!-- Birthdate -->
        <div class="form-group">
            <label>Fecha de Nacimiento</label>
            <input type="date" class="form-control" name="birthdate" value="<?php echo e($item->birthdate); ?>">
        </div>
        <?php $__errorArgs = ['birthdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./Birthdate -->

        <!-- BirthdatePlaceId -->
        <div class="form-group">
            <label>Lugar de Nacimiento:</label>
            <select name="birthdate_place_id" class="form-control select2bs4">
                <option value="-1">Seleccione el lugar de Nacimiento..</option>
                <?php $__empty_1 = true; $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($city->id); ?>"<?php echo e(isSelectedOld($item->birthdate_place_id, $city->id)); ?>>
                        <?php echo e('País: ' . $city->state->country->name . ' Departamento: ' . $city->state->name . '  Ciudad: ' . $city->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </select>
        </div>
        <?php $__errorArgs = ['birthdate_place_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./BirthdatePlaceId -->

        <!-- Address -->
        <div class="form-group">
            <label class="form-label">Dirección de Residencia:</label>
            <input type="text" class="form-control " name="address" value="<?php echo e($item->address); ?>">
        </div>
        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./Address -->

        <!-- Phone -->
        <div class="form-group">
            <label class="form-label">Celular Personal:</label>
            <input type="text" class="form-control " name="phone" value="<?php echo e($item->phone); ?>">
        </div>
        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./Phone -->

        <!-- Telephone -->
        <div class="form-group">
            <label class="form-label">Teléfono(Opcional):</label>
            <input type="text" class="form-control " name="telephone" value="<?php echo e($item->telephone); ?>">
        </div>
        <?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./Telephone -->

        <!-- Code -->
        <div class="form-group">
            <label class="form-label">Código Institucional:</label>
            <input type="text" class="form-control " name="code" value="<?php echo e($item->code); ?>">
        </div>
        <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./Code -->

        <!-- CompanyEmail -->
        <div class="form-group">
            <label class="form-label">Correo Institucional(@ufps):</label>
            <input type="email" class="form-control " name="company_email" value="<?php echo e($item->user); ?>"
                pattern=".+@ufps.edu.co" size="30">
        </div>
        <?php $__errorArgs = ['company_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./CompanyEmail -->

        <!-- Email -->
        <div class="form-group">
            <label class="form-label">Correo Personal:</label>
            <input type="email" class="form-control " name="email" value="<?php echo e($item->email); ?>" size="30">
        </div>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./Email -->

        <!-- Submit -->
        <button type="submit" class="btn btn-danger">Guardar</button>
        <!-- ./Submit -->
    </form>
    <!-- ./Form -->
<?php else: ?>
    <!-- Form -->
    <form action="<?php echo e(route('admin.graduates.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <!-- Name -->
        <div class="form-group">
            <label class="form-label">Nombres:</label>
            <input type="text" class="form-control " name="name" value="<?php echo e(old('name')); ?>">
        </div>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./Name -->

        <!-- Lastname -->
        <div class="form-group">
            <label class="form-label">Apellidos:</label>
            <input type="text" class="form-control " name="lastname" value="<?php echo e(old('lastname')); ?>">
        </div>
        <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./Lastname -->

        <!-- DocumentType -->
        <div class="form-group">
            <label>Tipo de Documento:</label>
            <select name="document_type_id" class="form-control select2bs4">
                <option value="-1">Seleccione un tipo de documento..</option>
                <?php $__empty_1 = true; $__currentLoopData = $documentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documentType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($documentType->id); ?>"
                        <?php echo e(isSelectedOld(old('document_type_id'), $documentType->id)); ?>><?php echo e($documentType->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </select>
        </div>
        <?php $__errorArgs = ['document_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./DocumentType -->

        <!-- Document -->
        <div class="form-group">
            <label class="form-label">Documento:</label>
            <input type="text" class="form-control " name="document" value="<?php echo e(old('document')); ?>">
        </div>
        <?php $__errorArgs = ['document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./Document -->

        <!-- Birthdate -->
        <div class="form-group">
            <label>Fecha de Nacimiento</label>
            <input type="date" class="form-control" name="birthdate" value="<?php echo e(old('birthdate')); ?>">
        </div>
        <?php $__errorArgs = ['birthdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./Birthdate -->

        <!-- BirthdatePlaceId -->
        <div class="form-group">
            <label>Lugar de Nacimiento:</label>
            <select name="birthdate_place_id" value="<?php echo e(old('birthdate_place_id')); ?>"
                class="form-control select2bs4">
                <option value="-1">Seleccione el lugar de Nacimiento..</option>
                <?php $__empty_1 = true; $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($city->id); ?>" <?php echo e(isSelectedOld(old('birthdate_place_id'), $city->id)); ?>>
                        <?php echo e('País: ' . $city->state->country->name . ' Departamento: ' . $city->state->name . '  Ciudad: ' . $city->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </select>
        </div>
        <?php $__errorArgs = ['birthdate_place_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./BirthdatePlaceId -->

        <!-- Address -->
        <div class="form-group">
            <label class="form-label">Dirección de Residencia:</label>
            <input type="text" class="form-control " name="address" value="<?php echo e(old('address')); ?>">
        </div>
        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./Address -->

        <!-- Phone -->
        <div class="form-group">
            <label class="form-label">Celular Personal:</label>
            <input type="text" class="form-control " name="phone" value="<?php echo e(old('phone')); ?>">
        </div>
        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./Phone -->

        <!-- Telephone -->
        <div class="form-group">
            <label class="form-label">Teléfono(Opcional):</label>
            <input type="text" class="form-control " name="telephone" value="<?php echo e(old('telephone')); ?>">
        </div>
        <?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./Telephone -->

        <!-- Code -->
        <div class="form-group">
            <label class="form-label">Código Institucional:</label>
            <input type="text" class="form-control " name="code" value="<?php echo e(old('code')); ?>">
        </div>
        <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./Code -->

        <!-- CompanyEmail -->
        <div class="form-group">
            <label class="form-label">Correo Institucional(@ufps):</label>
            <input type="email" class="form-control " name="company_email" value="<?php echo e(old('company_email')); ?>"
                pattern=".+@ufps.edu.co" size="30">
        </div>
        <?php $__errorArgs = ['company_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./CompanyEmail -->

        <!-- Email -->
        <div class="form-group">
            <label class="form-label">Correo Personal:</label>
            <input type="email" class="form-control " name="email" value="<?php echo e(old('email')); ?>"
                size="30">
        </div>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./Email -->

        <!-- File -->
        <div class="form-group">
            <label for="exampleFormControlFile1">Foto de Perfil</label>
            <input type="file" class="form-control-file" name="image">
        </div>
        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- ./File -->

        <!-- Submit -->
        <div class="mt-2">
            <button type="submit" class="btn btn-danger">Guardar</button>
        </div>
        <!-- ./Submit -->
    </form>
    <!-- ./Form -->
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/admin/pages/graduates/form.blade.php ENDPATH**/ ?>