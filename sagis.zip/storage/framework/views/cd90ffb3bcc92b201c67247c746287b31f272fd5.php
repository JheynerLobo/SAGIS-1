<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1><?php echo e($title); ?></h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(isset($item['route']) && $item['route']): ?>
                            <li class="breadcrumb-item <?php echo e($item['isActive']); ?>">
                                <a href="<?php echo e($item['route']); ?>"><?php echo e($item['name']); ?></a>
                            </li>
                        <?php else: ?>
                            <li class="breadcrumb-item <?php echo e($item['isActive']); ?>"><?php echo e($item['name']); ?></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /var/www/html/resources/views/dev/admin/partials/content-header.blade.php ENDPATH**/ ?>