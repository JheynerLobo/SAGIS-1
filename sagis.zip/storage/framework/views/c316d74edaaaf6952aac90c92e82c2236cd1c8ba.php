<?php $__env->startSection('tittle', 'Cursos'); ?>


<?php $__env->startSection('content'); ?>

    <?php echo $filters; ?>


    <section class=" mt-5 mb-5">

        <?php echo $table; ?>

    </section>

    <div class="container">
        <?php echo e($items->links('partials.pagination.default')); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/pages/courses/index.blade.php ENDPATH**/ ?>