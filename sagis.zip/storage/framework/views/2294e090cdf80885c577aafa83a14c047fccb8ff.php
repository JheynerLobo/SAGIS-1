<div class="container-fluid mt-4">
    <div class="table-responsive">
        <table class="table table-sm table-hover table-bordered table-striped">
            <thead>
                <tr>
                    <th>Título</th>
                    <th>Categoría</th>
                    <th>Description</th>
                    <th>Fecha de Publicación</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($item->title); ?></td>
                        <td><?php echo e($item->postCategory->name); ?></td>
                        <td><?php echo e($item->description); ?></td>
                        <td><?php echo e($item->date); ?></td>
                        <td>
                            <div class="btn-group">
                                <a href="<?php echo e(route('admin.posts.edit', $item->id)); ?>" class="btn btn-sm btn-warning"><i
                                        class="fas fa-edit"></i></a>
                                <form action="<?php echo e(route('admin.posts.destroy', $item->id)); ?>"
                                    id="<?php echo e($item->id); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger"><i class="fas fa-trash"
                                            onclick="destroy(event, <?php echo e($item->id); ?>, '¡Se elimninará la publicación!')"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>
<?php /**PATH /var/www/html/resources/views/admin/pages/posts/table.blade.php ENDPATH**/ ?>