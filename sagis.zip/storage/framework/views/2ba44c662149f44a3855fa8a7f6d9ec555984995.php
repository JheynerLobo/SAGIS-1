<?php $__env->startSection('title', 'Graduados'); ?>

<?php $__env->startSection('content-header'); ?>
    <?php echo $__env->make('dev.admin.partials.content-header', [
        'title' => 'Graduados',
        'items' => [
            [
                'name' => 'Inicio',
                'route' => route('dev.home'),
                'isActive' => null,
            ],
            [
                'name' => 'Graduados',
                'route' => null,
                'isActive' => 'active',
            ],
        ],
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header  border-info">
                            <h3 class="card-title"><b>Graduados registrados</b> </h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>N°</th>
                                        <th>Nombre</th>
                                        <th>Cedula</th>
                                        <th>Código</th>
                                        <th>Celular</th>
                                        <th>Correo institucional</th>
                                        <th>Ver datos completos</th>
                                        <th>Estado verificado</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>Jarlin Andres Fonseca Bermón</td>
                                        <td>100687978</td>
                                        <td>1151758</td>
                                        <td>3238123367</td>
                                        <td>jarlinandresfb@ufps.edu.co</td>
                                        <td style="text-align: center">
                                            

                                            
                                            <a href="<?php echo e(route('dev.students.academics.information')); ?>">
                                                <button style=" border: none ;background-color: transparent" type="submit">
                                                    <img src="<?php echo e(asset('img/lupa.png')); ?>"
                                                        style="display: block; width: 30px; height: 30px; margin:auto;" />
                                                </button>

                                            </a>

                                            
                                        </td>
                                        <td>

                                            <img src="<?php echo e(asset('img/aprobado.png')); ?>" alt=""
                                                style="display: block; width: 30px; height: 30px; margin:auto;">


                                        </td>
                                        <td>
                                            <div class="icons-acciones">

                                                <div class="mr-3">

                                                    <a style="text-decoration: none; color: #000000;"
                                                        href="<?php echo e(route('dev.students.edit')); ?>">

                                                        <button type="button" class="fas fa-edit"
                                                            style="width: 30px; height: 30px"
                                                            data-bs-whatever="<%=persona.getContraseña()%>"></button>



                                                    </a>


                                                </div>
                                                <div>

                                                    <a style="text-decoration: none; color: #000000;"
                                                        href="<?php echo e(route('dev.students.edit_password')); ?>">

                                                        <button type="button" class="fas fa-key"
                                                            style="width: 25px; height: 25px"
                                                            data-bs-whatever="<%=persona.getContraseña()%>"></button>


                                                    </a>

                                                </div>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>Juan Hernandez</td>
                                        <td>9944787</td>
                                        <td>1151759</td>
                                        <td>31785547</td>
                                        <td>juanhna@ufps.edu.co</td>
                                        <td style="text-align: center">
                                            <form action="<%=basePath%>/MostrarFichaTecnica.do" method="POST">

                                                <input style="display: none" type="text" class="form-control "
                                                    value="<%=persona.getCedula()%>" id="exampleInputNombre" name="cedula"
                                                    required>
                                                <button style=" border: none ;background-color: transparent" type="submit">
                                                    <img src="<?php echo e(asset('img/lupa.png')); ?>"
                                                        style="display: block; width: 30px; height: 30px;            margin:auto;" />
                                                </button>
                                            </form>
                                        </td>
                                        <td>

                                            <img src="<?php echo e(asset('img/rechazo.png')); ?>" alt=""
                                                style="display: block; width: 30px; height: 30px; margin:auto;">


                                        </td>
                                        <td>
                                            <div class="icons-acciones">

                                                <div class="mr-3">
                                                    <button type="button" class="fas fa-edit"
                                                        style="width: 30px; height: 30px"
                                                        data-bs-whatever="<%=persona.getContraseña()%>"></button>

                                                </div>
                                                <div>
                                                    <button type="button" class="fas fa-key"
                                                        style="width: 25px; height: 25px"
                                                        data-bs-whatever="<%=persona.getContraseña()%>"></button>

                                                </div>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <td>5</td>
                                        <td>Lucas Manuel Tiria</td>
                                        <td>1079844</td>
                                        <td>1151770</td>
                                        <td>315744844</td>
                                        <td>lucasmn@ufps.edu.co</td>
                                        <td style="text-align: center">
                                            <form action="<%=basePath%>/MostrarFichaTecnica.do" method="POST">

                                                <input style="display: none" type="text" class="form-control "
                                                    value="<%=persona.getCedula()%>" id="exampleInputNombre" name="cedula"
                                                    required>
                                                <button style=" border: none ;background-color: transparent" type="submit">
                                                    <img src="<?php echo e(asset('img/lupa.png')); ?>"
                                                        style="display: block; width: 30px; height: 30px;            margin:auto;" />
                                                </button>
                                            </form>
                                        </td>
                                        <td>

                                            <img src="<?php echo e(asset('img/aprobado.png')); ?>" alt=""
                                                style="display: block; width: 30px; height: 30px; margin:auto;">


                                        </td>
                                        <td>
                                            <div class="icons-acciones">

                                                <div class="mr-3">
                                                    <button type="button" class="fas fa-edit"
                                                        style="width: 30px; height: 30px"
                                                        data-bs-whatever="<%=persona.getContraseña()%>"></button>

                                                </div>
                                                <div>
                                                    <button type="button" class="fas fa-key"
                                                        style="width: 25px; height: 25px"
                                                        data-bs-whatever="<%=persona.getContraseña()%>"></button>

                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>7</td>
                                        <td>Andres Castillo</td>
                                        <td>10079877</td>
                                        <td>1151780</td>
                                        <td>312443367</td>
                                        <td>andresxb@ufps.edu.co</td>
                                        <td style="text-align: center">
                                            <form action="<%=basePath%>/MostrarFichaTecnica.do" method="POST">

                                                <input style="display: none" type="text" class="form-control "
                                                    value="<%=persona.getCedula()%>" id="exampleInputNombre" name="cedula"
                                                    required>
                                                <button style=" border: none ;background-color: transparent" type="submit">
                                                    <img src="<?php echo e(asset('img/lupa.png')); ?>"
                                                        style="display: block; width: 30px; height: 30px;            margin:auto;" />
                                                </button>
                                            </form>
                                        </td>
                                        <td>

                                            <img src="<?php echo e(asset('img/aprobado.png')); ?>" alt=""
                                                style="display: block; width: 30px; height: 30px; margin:auto;">


                                        </td>
                                        <td>
                                            <div class="icons-acciones">

                                                <div class="mr-3">
                                                    <button type="button" class="fas fa-edit"
                                                        style="width: 30px; height: 30px"
                                                        data-bs-whatever="<%=persona.getContraseña()%>"></button>

                                                </div>
                                                <div>
                                                    <button type="button" class="fas fa-key"
                                                        style="width: 25px; height: 25px"
                                                        data-bs-whatever="<%=persona.getContraseña()%>"></button>

                                                </div>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <td>10</td>
                                        <td>Felipe Mora</td>
                                        <td>1007887978</td>
                                        <td>1151795</td>
                                        <td>35477875</td>
                                        <td>felipemrafb@ufps.edu.co</td>
                                        <td style="text-align: center">
                                            <form action="<%=basePath%>/MostrarFichaTecnica.do" method="POST">

                                                <input style="display: none" type="text" class="form-control "
                                                    value="<%=persona.getCedula()%>" id="exampleInputNombre"
                                                    name="cedula" required>
                                                <button style=" border: none ;background-color: transparent"
                                                    type="submit">
                                                    <img src="<?php echo e(asset('img/lupa.png')); ?>"
                                                        style="display: block; width: 30px; height: 30px;            margin:auto;" />
                                                </button>
                                            </form>
                                        </td>
                                        <td>

                                            <img src="<?php echo e(asset('img/rechazo.png')); ?>" alt=""
                                                style="display: block; width: 30px; height: 30px; margin:auto;">


                                        </td>
                                        <td>
                                            <div class="icons-acciones">

                                                <div class="mr-3">
                                                    <button type="button" class="fas fa-edit"
                                                        style="width: 30px; height: 30px"
                                                        data-bs-whatever="<%=persona.getContraseña()%>"></button>

                                                </div>
                                                <div>
                                                    <button type="button" class="fas fa-key"
                                                        style="width: 25px; height: 25px"
                                                        data-bs-whatever="<%=persona.getContraseña()%>"></button>

                                                </div>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <td>20</td>
                                        <td>Juliana Sanchez</td>
                                        <td>10775475</td>
                                        <td>1151854</td>
                                        <td>3175474474</td>
                                        <td>julianafb@ufps.edu.co</td>
                                        <td style="text-align: center">
                                            <form action="<%=basePath%>/MostrarFichaTecnica.do" method="POST">

                                                <input style="display: none" type="text" class="form-control "
                                                    value="<%=persona.getCedula()%>" id="exampleInputNombre"
                                                    name="cedula" required>
                                                <button style=" border: none ;background-color: transparent"
                                                    type="submit">
                                                    <img src="<?php echo e(asset('img/lupa.png')); ?>"
                                                        style="display: block; width: 30px; height: 30px; margin:auto;" />
                                                </button>
                                            </form>
                                        </td>
                                        <td>

                                            <img src="<?php echo e(asset('img/aprobado.png')); ?>" alt=""
                                                style="display: block; width: 30px; height: 30px; margin:auto;">


                                        </td>
                                        <td>
                                            <div class="icons-acciones">

                                                <div class="mr-3">

                                                    <button type="button" class="fas fa-edit"
                                                        style="width: 30px; height: 30px"></button>


                                                </div>
                                                <div>
                                                    <button type="button" class="fas fa-key"
                                                        style="width: 25px; height: 25px"
                                                        data-bs-whatever="<%=persona.getContraseña()%>"></button>

                                                </div>
                                            </div>
                                        </td>

                                    </tr>


                                </tbody>

                            </table>

                            

                            <a href="<?php echo e(route('dev.students.create')); ?>"> <button type="button"
                                    class="btn btn-danger btn-lg  btn-sm mt-5" style="float: right;"> Añadir nuevo
                                    graduado </button></a>



                            

                            

                        </div>
                        <!-- /.card-body -->


                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- DataTables  & Plugins -->
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/jszip/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/pdfmake/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/pdfmake/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
    <script>
        $(function() {
            $("#example1").DataTable({
                "responsive": true,
                "lengthChange": false,
                "autoWidth": false,
                "buttons": ["copy", "csv", "excel", "pdf", "print"],
                "language": {

                    "processing": "Procesando...",
                    "lengthMenu": "Mostrar _MENU_ registros",
                    "zeroRecords": "No se encontraron resultados",
                    "emptyTable": "Ningún dato disponible en esta tabla",
                    "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
                    "infoFiltered": "(filtrado de un total de _MAX_ registros)",
                    "search": "Buscar:",
                    "infoThousands": ",",
                    "loadingRecords": "Cargando...",
                    "paginate": {
                        "first": "Primero",
                        "last": "Último",
                        "next": "Siguiente",
                        "previous": "Anterior"
                    },
                    "aria": {
                        "sortAscending": ": Activar para ordenar la columna de manera ascendente",
                        "sortDescending": ": Activar para ordenar la columna de manera descendente"
                    },
                    "buttons": {
                        "copy": "Copiar",
                        "colvis": "Visibilidad",
                        "collection": "Colección",
                        "colvisRestore": "Restaurar visibilidad",
                        "copyKeys": "Presione ctrl o u2318 + C para copiar los datos de la tabla al portapapeles del sistema. <br \/> <br \/> Para cancelar, haga clic en este mensaje o presione escape.",
                        "copySuccess": {
                            "1": "Copiada 1 fila al portapapeles",
                            "_": "Copiadas %ds fila al portapapeles"
                        },
                        "copyTitle": "Copiar al portapapeles",
                        "csv": "CSV",
                        "excel": "Excel",
                        "pageLength": {
                            "-1": "Mostrar todas las filas",
                            "_": "Mostrar %d filas"
                        },
                        "pdf": "PDF",
                        "print": "Imprimir",
                        "renameState": "Cambiar nombre",
                        "updateState": "Actualizar",
                        "createState": "Crear Estado",
                        "removeAllStates": "Remover Estados",
                        "removeState": "Remover",
                        "savedStates": "Estados Guardados",
                        "stateRestore": "Estado %d"
                    },
                    "autoFill": {
                        "cancel": "Cancelar",
                        "fill": "Rellene todas las celdas con <i>%d<\/i>",
                        "fillHorizontal": "Rellenar celdas horizontalmente",
                        "fillVertical": "Rellenar celdas verticalmentemente"
                    },
                    "decimal": ",",
                    "searchBuilder": {
                        "add": "Añadir condición",
                        "button": {
                            "0": "Constructor de búsqueda",
                            "_": "Constructor de búsqueda (%d)"
                        },
                        "clearAll": "Borrar todo",
                        "condition": "Condición",
                        "conditions": {
                            "date": {
                                "after": "Despues",
                                "before": "Antes",
                                "between": "Entre",
                                "empty": "Vacío",
                                "equals": "Igual a",
                                "notBetween": "No entre",
                                "notEmpty": "No Vacio",
                                "not": "Diferente de"
                            },
                            "number": {
                                "between": "Entre",
                                "empty": "Vacio",
                                "equals": "Igual a",
                                "gt": "Mayor a",
                                "gte": "Mayor o igual a",
                                "lt": "Menor que",
                                "lte": "Menor o igual que",
                                "notBetween": "No entre",
                                "notEmpty": "No vacío",
                                "not": "Diferente de"
                            },
                            "string": {
                                "contains": "Contiene",
                                "empty": "Vacío",
                                "endsWith": "Termina en",
                                "equals": "Igual a",
                                "notEmpty": "No Vacio",
                                "startsWith": "Empieza con",
                                "not": "Diferente de",
                                "notContains": "No Contiene",
                                "notStarts": "No empieza con",
                                "notEnds": "No termina con"
                            },
                            "array": {
                                "not": "Diferente de",
                                "equals": "Igual",
                                "empty": "Vacío",
                                "contains": "Contiene",
                                "notEmpty": "No Vacío",
                                "without": "Sin"
                            }
                        },
                        "data": "Data",
                        "deleteTitle": "Eliminar regla de filtrado",
                        "leftTitle": "Criterios anulados",
                        "logicAnd": "Y",
                        "logicOr": "O",
                        "rightTitle": "Criterios de sangría",
                        "title": {
                            "0": "Constructor de búsqueda",
                            "_": "Constructor de búsqueda (%d)"
                        },
                        "value": "Valor"
                    },
                    "searchPanes": {
                        "clearMessage": "Borrar todo",
                        "collapse": {
                            "0": "Paneles de búsqueda",
                            "_": "Paneles de búsqueda (%d)"
                        },
                        "count": "{total}",
                        "countFiltered": "{shown} ({total})",
                        "emptyPanes": "Sin paneles de búsqueda",
                        "loadMessage": "Cargando paneles de búsqueda",
                        "title": "Filtros Activos - %d",
                        "showMessage": "Mostrar Todo",
                        "collapseMessage": "Colapsar Todo"
                    },
                    "select": {
                        "cells": {
                            "1": "1 celda seleccionada",
                            "_": "%d celdas seleccionadas"
                        },
                        "columns": {
                            "1": "1 columna seleccionada",
                            "_": "%d columnas seleccionadas"
                        },
                        "rows": {
                            "1": "1 fila seleccionada",
                            "_": "%d filas seleccionadas"
                        }
                    },
                    "thousands": ".",
                    "datetime": {
                        "previous": "Anterior",
                        "next": "Proximo",
                        "hours": "Horas",
                        "minutes": "Minutos",
                        "seconds": "Segundos",
                        "unknown": "-",
                        "amPm": [
                            "AM",
                            "PM"
                        ],
                        "months": {
                            "0": "Enero",
                            "1": "Febrero",
                            "10": "Noviembre",
                            "11": "Diciembre",
                            "2": "Marzo",
                            "3": "Abril",
                            "4": "Mayo",
                            "5": "Junio",
                            "6": "Julio",
                            "7": "Agosto",
                            "8": "Septiembre",
                            "9": "Octubre"
                        },
                        "weekdays": [
                            "Dom",
                            "Lun",
                            "Mar",
                            "Mie",
                            "Jue",
                            "Vie",
                            "Sab"
                        ]
                    },
                    "editor": {
                        "close": "Cerrar",
                        "create": {
                            "button": "Nuevo",
                            "title": "Crear Nuevo Registro",
                            "submit": "Crear"
                        },
                        "edit": {
                            "button": "Editar",
                            "title": "Editar Registro",
                            "submit": "Actualizar"
                        },
                        "remove": {
                            "button": "Eliminar",
                            "title": "Eliminar Registro",
                            "submit": "Eliminar",
                            "confirm": {
                                "_": "¿Está seguro que desea eliminar %d filas?",
                                "1": "¿Está seguro que desea eliminar 1 fila?"
                            }
                        },
                        "error": {
                            "system": "Ha ocurrido un error en el sistema (<a target=\"\\\" rel=\"\\ nofollow\" href=\"\\\">Más información&lt;\\\/a&gt;).<\/a>"
                        },
                        "multi": {
                            "title": "Múltiples Valores",
                            "info": "Los elementos seleccionados contienen diferentes valores para este registro. Para editar y establecer todos los elementos de este registro con el mismo valor, hacer click o tap aquí, de lo contrario conservarán sus valores individuales.",
                            "restore": "Deshacer Cambios",
                            "noMulti": "Este registro puede ser editado individualmente, pero no como parte de un grupo."
                        }
                    },
                    "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
                    "stateRestore": {
                        "creationModal": {
                            "button": "Crear",
                            "name": "Nombre:",
                            "order": "Clasificación",
                            "paging": "Paginación",
                            "search": "Busqueda",
                            "select": "Seleccionar",
                            "columns": {
                                "search": "Búsqueda de Columna",
                                "visible": "Visibilidad de Columna"
                            },
                            "title": "Crear Nuevo Estado",
                            "toggleLabel": "Incluir:"
                        },
                        "emptyError": "El nombre no puede estar vacio",
                        "removeConfirm": "¿Seguro que quiere eliminar este %s?",
                        "removeError": "Error al eliminar el registro",
                        "removeJoiner": "y",
                        "removeSubmit": "Eliminar",
                        "renameButton": "Cambiar Nombre",
                        "renameLabel": "Nuevo nombre para %s",
                        "duplicateError": "Ya existe un Estado con este nombre.",
                        "emptyStates": "No hay Estados guardados",
                        "removeTitle": "Remover Estado",
                        "renameTitle": "Cambiar Nombre Estado"
                    }
                }
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dev.admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/dev/admin/pages/students/index.blade.php ENDPATH**/ ?>