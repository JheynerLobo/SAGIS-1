<div class="container ">
    <div class="row g-5">
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-12 col-md-6 col-lg-4">
                <div class="card " style="width: 21rem; height: 580px;">
                    <div class="embed-responsive embed-responsive-16by9">
                        <iframe class="embed-responsive-item" src="<?php echo e($item->videoHeader()->fullAsset()); ?>"
                            allowfullscreen></iframe>
                    </div>
                    <div class="card-body">
                        <p class="fecha"><?php echo e($item->date); ?></p>
                        <h5 class="card-title"> <a href="" class="vinculoTitulo"><?php echo e($item->title); ?></a></h5>
                        <p class="card-text"><?php echo e($item->description); ?></p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="botonGC btn btn-danger">Leer más...</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h4>No hay videos registrados.</h4>
        <?php endif; ?>
    </div>


</div>
<?php /**PATH /var/www/html/resources/views/pages/videos/table.blade.php ENDPATH**/ ?>