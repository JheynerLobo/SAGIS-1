<?php $__env->startSection('title', 'Publicaciones'); ?>

<?php $__env->startSection('content-header'); ?>
    <?php echo $__env->make('admin.partials.content-header', [
        'title' => 'Contenido Informativo',
        'items' => [
            [
                'name' => 'Inicio',
                'route' => route('admin.home'),
                'isActive' => null,
            ],
            [
                'name' => 'Publicaciones',
                'route' => null,
                'isActive' => 'active',
            ],
        ],
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">

                <!-- Filters -->
                <?php echo $filters; ?>

                <!-- ./Filters -->

                <!-- Table -->
                <?php echo $table; ?>

                <!-- ./Table -->

                <?php echo e($items->links('partials.pagination.default')); ?>

            </div>
        </div>
    </section>

    <?php echo $__env->make('admin.partials.button_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/pages/posts/index.blade.php ENDPATH**/ ?>