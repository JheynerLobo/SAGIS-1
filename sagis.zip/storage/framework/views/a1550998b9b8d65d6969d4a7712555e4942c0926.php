<?php $__env->startSection('title', 'Agregar Contenidos'); ?>



<?php $__env->startSection('content-header'); ?>
    <?php echo $__env->make('dev.admin.partials.content-header', [
        'title' => 'Agregar contenidos informativos',
        'items' => [
            [
                'name' => 'Inicio',
                'route' => route('dev.home'),
                'isActive' => null,
            ],
            [
                'name' => 'Graduados',
                'route' => route('dev.students'),
                'isActive' => null,
            ],
            [
                'name' => 'Estadisticas',
                'route' => null,
                'isActive' => 'active'
            ]
        ],
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

 <!-- Main content -->
 <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="card card-outline card-info">
          <div class="card-header">
            <h3 class="card-title">
              Summernote
            </h3>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <textarea id="summernote">
              Place <em>some</em> <u>text</u> <strong>here</strong>
            </textarea>
          </div>
          <div class="card-footer">
            Visit <a href="https://github.com/summernote/summernote/">Summernote</a> documentation for more examples and information about the plugin.
          </div>
        </div>
      </div>
      <!-- /.col-->
    </div>
    <!-- ./row -->
    
    <!-- ./row -->
  </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dev.admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/dev/admin/pages/posts/index.blade.php ENDPATH**/ ?>